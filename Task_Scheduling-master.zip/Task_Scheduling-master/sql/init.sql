-- Run this to create the projects table
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    deadline INT NOT NULL,
    revenue INT NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
);
